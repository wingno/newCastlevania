Ripped By Anex~. The title screen Eclipse will be separate from this one, as this was a COMPLEX animation to capture.

Platform: GBA
Game: Castlevania- Aria of Sorrow
Subject: Intro Eclipse

If used, please credit the original authors of the sprites & producers.
No Copyright Infringment Intended.